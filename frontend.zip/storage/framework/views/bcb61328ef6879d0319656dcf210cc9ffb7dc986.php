<!DOCTYPE html>
<html>
    <head>
        <title>Leaders</title>
    </head>
</html>



<?php $__env->startSection('mainpage'); ?>
    <div>
        <div class="hero h-[20rem] relative" style="background-image: url(<?php echo e(asset('assets/backgroundimage/ref3.jpg')); ?>);">
            <div class="hero-overlay bg-black/20 "></div>
            <div class="absolute top-14 text-white">
                <div class="max-w-2xl">
                    <h1 class="mb-5 text-5xl font-bold uppercase"><?php echo app('translator')->get('public.navtext3'); ?></h1>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.leadersimages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/layouts/leaders.blade.php ENDPATH**/ ?>