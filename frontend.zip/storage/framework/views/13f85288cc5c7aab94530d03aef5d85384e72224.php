<!DOCTYPE html>
<html>
    <head>
        <title>Photo Gallery</title>
    </head>
</html>



<?php $__env->startSection('mainpage'); ?>
    <div class="hero h-[20rem] relative" style="background-image: url(<?php echo e(asset('assets/backgroundimage/ref3.jpg')); ?>);">
        <div class="hero-overlay bg-black/20 "></div>
        <div class="absolute top-14 text-white">
            <div class="max-w-md">
                <h1 class="mb-5 text-5xl font-bold uppercase"><?php echo app('translator')->get('public.navdrop3'); ?></h1>
            </div>
        </div>
    </div>

    <div class="flex justify-center mt-20 mb-10">
        <div class="container max-w-6xl lg:px-0 px-5">
            <div class="grid md:grid-cols-2 gap-y-2 justify-center">
                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>
                
                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>

                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>

                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>

                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>

                <div class="bg-gray-200 p-4 w-fit border border-black/10">
                    <img src="<?php echo e(asset('assets/backgroundimage/offceteam.jpg')); ?>" alt="i">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/layouts/photogallery.blade.php ENDPATH**/ ?>