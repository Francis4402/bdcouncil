<div class="bg-[#f7f7f7] border">
    <div class="p-5 flex md:flex-row flex-col gap-5">
        <div class="flex flex-col gap-2">
            <h1 class="font-bold"><?php echo app('translator')->get('public.ft1'); ?></h1>
            <p class="flex gap-2"><input type="checkbox"> <?php echo app('translator')->get('public.f1'); ?></p>
            <p class="flex gap-2"><input type="checkbox"> <?php echo app('translator')->get('public.f2'); ?></p>
            <p class="flex gap-2"><input type="checkbox"> <?php echo app('translator')->get('public.f3'); ?></p>
        </div>
    
        <div class="flex flex-col gap-2">
            <h1 class="font-bold"><?php echo app('translator')->get('public.ft4'); ?></h1>
            <p class="flex gap-2"><input type="checkbox" class="outline-none"> <?php echo app('translator')->get('public.newest'); ?></p>
            <p class="flex gap-2"><input type="checkbox" class="outline-none"> <?php echo app('translator')->get('public.ft2'); ?></p>
            <p class="flex gap-2"><input type="checkbox" class="outline-none"> <?php echo app('translator')->get('public.f4'); ?></p>
            <p class="flex gap-2"><input type="checkbox" class="outline-none"> <?php echo app('translator')->get('public.f5'); ?></p>
            <p class="flex gap-2"><input type="checkbox" class="outline-none"> <?php echo app('translator')->get('public.f6'); ?></p>
        </div>
    
        <div class="flex flex-col gap-2">
            <h1 class="font-bold"><?php echo app('translator')->get('public.ft3'); ?></h1>
            <p class="flex gap-2"><input type="checkbox"> <?php echo app('translator')->get('public.f7'); ?></p>
            <p class="flex gap-2"><input type="checkbox"> <?php echo app('translator')->get('public.f8'); ?></p>
            <input type="text" class="py-2 px-5 border rounded-lg" placeholder="e.g javascript or python">
        </div>
    </div>
    <hr/>
    <div class="p-5">
        
        <div class="flex justify-between">
            <button class="btn btn-primary"><?php echo app('translator')->get('public.f9'); ?></button>
            <button><?php echo app('translator')->get('public.f10'); ?></button>
        </div>
    </div>
</div><?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/filterdropdown/filterdropdown.blade.php ENDPATH**/ ?>