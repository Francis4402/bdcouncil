<dialog id="my_modal_1" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/1-1.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name1'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position1'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes1'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>

<dialog id="my_modal_2" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/2-1.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name2'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position2'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes2'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_3" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/3.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name3'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position3'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes3'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_4" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/4-1.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name4'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position4'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes4'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_5" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/6.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name5'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position5'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes5'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_6" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/7.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name6'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position6'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes6'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_7" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/8.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name7'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position7'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes7'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_8" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/12.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name8'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position8'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes8'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_9" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/13.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name9'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position9'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes9'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog>


<dialog id="my_modal_10" class="modal">
  <div class="modal-box max-w-4xl">
    <form method="dialog">
      <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
    </form>
    <div class="flex md:flex-row flex-col justify-center gap-4 items-start">
        <img class="w-60 bg-white shadow-lg" src="https://buyerscouncil.org/wp-content/uploads/2024/02/15.jpg" alt="i" />
        
        <div>
            <h3 class="font-bold text-2xl"><?php echo app('translator')->get('public.name10'); ?></h3>
            <p class="text-[#a1a1a1]"><?php echo app('translator')->get('public.position10'); ?></p>
            <p class="py-4 w-full"><?php echo app('translator')->get('public.popupdes10'); ?></p>

            <div class="flex gap-4 items-center">
              <a href="https://www.facebook.com" class="bg-gray-300 rounded-full p-2 hover:bg-[#3b5998] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/facebook-app-symbol.png')); ?>" alt="i"/>
              </a>
              <a href="https://twitter.com/?lang=en" class="bg-gray-300 rounded-full p-2 hover:bg-[#1da1f2] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/twitter.png')); ?>" alt="i"/>
              </a>
              <a href="https://www.pinterest.com/" class="bg-gray-300 rounded-full p-2 hover:bg-[#e60023] hover:animate-bounce duration-200">
                  <img width="20px" height="20px" src="<?php echo e(asset('assets/icons/pinterest.png')); ?>" alt="i"/>
              </a>
            </div>
        </div>
    </div>
  </div>
</dialog><?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/popups/popup.blade.php ENDPATH**/ ?>