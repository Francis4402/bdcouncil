<div class="flex justify-center bg-[#2d2d2d] mt-10">
    <div class="container max-w-6xl md:px-0 px-5">
        <div class="p-16">
            <div class="flex md:flex-row flex-col items-start justify-between md:gap-0 gap-10">
                <div class="flex flex-col max-w-lg gap-4">
                    <h4 class="text-lg font-bold text-[#c4c4c4]"><?php echo app('translator')->get('public.footertitle'); ?></h4>
    
                    <div>
                        <p class="text-[#b2b2b2]"><?php echo app('translator')->get('public.footeraddress1'); ?></p>
                        <p class="text-[#b2b2b2]"><?php echo app('translator')->get('public.footeradress2'); ?></p>
                    </div>
                </div>

                <div class="grid md:grid-cols-3 gap-10 items-start">
                    <div class="flex flex-col gap-4">
                        <h4 class="text-lg font-bold text-[#c4c4c4]"><?php echo app('translator')->get('public.footertitle1'); ?></h4>
                        <div class="text-[#c4c4c4] gap-2 flex flex-col">
                            <a href="/"><?php echo app('translator')->get('public.ft1'); ?></a>
                            <a href=<?php echo e(route('whoweare')); ?>><?php echo app('translator')->get('public.navtext1'); ?></a>
                            <a href=<?php echo e(route('ourpanellist')); ?>><?php echo app('translator')->get('public.navtext2'); ?></a>
                            <a href=<?php echo e(route('leaders')); ?>><?php echo app('translator')->get('public.navtext3'); ?></a>
                            <a href=<?php echo e(route('blog')); ?>><?php echo app('translator')->get('public.navtext7'); ?></a>
                            <a href=<?php echo e(route('contactus')); ?>><?php echo app('translator')->get('public.navtext8'); ?></a>
                        </div>
                    </div>
        
                    <div class="flex flex-col gap-4">
                        <h4 class="text-lg font-bold text-[#c4c4c4]"><?php echo app('translator')->get('public.footertitle2'); ?></h4>
                        <div class="text-[#c4c4c4] gap-2 flex flex-col">
                            <a href=<?php echo e(route('newsevents')); ?>><?php echo app('translator')->get('public.navdrop1'); ?></a>
                            <a href=<?php echo e(route('recentactivity')); ?>><?php echo app('translator')->get('public.navdrop2'); ?></a>
                            <a href=<?php echo e(route('photogallery')); ?>><?php echo app('translator')->get('public.navdrop3'); ?></a>
                            <a href="https://www.youtube.com/@BuyersCouncil/videos"><?php echo app('translator')->get('public.navdrop4'); ?></a>
                        </div>
                    </div>
        
                    <div class="flex flex-col gap-4">
                        <h4 class="text-lg font-bold text-[#c4c4c4]"><?php echo app('translator')->get('public.footertitle3'); ?></h4>
                        <div class="text-[#c4c4c4] gap-2 flex flex-col">
                            <a href="/"><?php echo app('translator')->get('public.ft2'); ?></a>
                            <a href="/"><?php echo app('translator')->get('public.ft3'); ?></a>
                            <a href="/"><?php echo app('translator')->get('public.ft4'); ?></a>
                            <a href="/"><?php echo app('translator')->get('public.ft5'); ?></a>
                            <a href="/"><?php echo app('translator')->get('public.ft6'); ?></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="text-[#b2b2b2] text-xs flex justify-center pb-10 customfont">
            <?php echo app('translator')->get('public.copyright'); ?>
        </div>

    </div>
</div>
<?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/mainpages/footer.blade.php ENDPATH**/ ?>