<!DOCTYPE html>
<html>
    <head>
        <title>Who We Are</title>
    </head>
</html>

<?php $__env->startSection('mainpage'); ?>

<div>
    <div class="hero h-[20rem]" style="background-image: url(<?php echo e(asset('assets/backgroundimage/ref3.jpg')); ?>);">
        <div class="hero-overlay bg-black/60 "></div>
        <div class="hero-content text-center text-white">
            <div class="max-w-2xl">
                <h1 class="mb-5 text-5xl font-bold uppercase"><?php echo app('translator')->get('public.navtext1'); ?></h1>
            </div>
        </div>
    </div>

    <div class="flex justify-center my-20">
        <div class="container max-w-6xl lg:px-0 px-5">
            <div class="flex flex-col justify-center gap-6">

                <h4 class="text-2xl font-bold flex justify-center"><?php echo app('translator')->get('public.whoareyoutitle'); ?></h4>

                <p class="text-[#7a7a7a] text-lg">
                    <?php echo app('translator')->get('public.whoareyoudescription'); ?>
                </p>
            </div>
        </div>
    </div>

    <div class="text-white grid md:grid-cols-3 gap-2">
        <div class="bg-[#008000] card-body">
            <h1 class="text-2xl font-bold"><?php echo app('translator')->get('public.introducingt3'); ?></h1>
            <p class="text-lg"><?php echo app('translator')->get('public.whoaredes7'); ?></p>
        </div>

        <div class="bg-[#ff0000] card-body">
            <h1 class="text-2xl font-bold"><?php echo app('translator')->get('public.introducingt5'); ?></h1>
            <p class="text-lg"><?php echo app('translator')->get('public.whoaredes8'); ?></p>
        </div>

        <div class="bg-[#008000] card-body">
            <h1 class="text-2xl font-bold"><?php echo app('translator')->get('public.introducingt7'); ?></h1>
            <p class="text-lg"><?php echo app('translator')->get('public.whoaredes9'); ?></p>
        </div>
    </div>

    <div class="flex justify-center my-20">
        <div class="container max-w-6xl lg:px-0 px-5">
            <div class="flex flex-col justify-center gap-6">
                <h4 class="text-2xl font-bold flex justify-center"><?php echo app('translator')->get('public.whoareyoutitle1'); ?></h4>

                <div class="flex flex-col gap-4">
                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.1'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle1'); ?></span> <?php echo app('translator')->get('public.whoaredes1'); ?></p>

                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.2'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle2'); ?></span> <?php echo app('translator')->get('public.whoaredes2'); ?></p>

                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.3'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle3'); ?></span> <?php echo app('translator')->get('public.whoaredes3'); ?></p>

                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.4'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle4'); ?></span> <?php echo app('translator')->get('public.whoaredes4'); ?></p>

                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.5'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle5'); ?></span> <?php echo app('translator')->get('public.whoaredes5'); ?></p>

                    <p class="text-[#7a7a7a] text-lg"><?php echo app('translator')->get('public.6'); ?>. <span class="font-bold"><?php echo app('translator')->get('public.whoareyoudescriptiontitle6'); ?></span> <?php echo app('translator')->get('public.whoaredes6'); ?></p>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravelbussinessproject\frontend\resources\views/layouts/who-we-are-page.blade.php ENDPATH**/ ?>