

const mix = require('laravel-mix')

mix.js('resources/js/app.js', 'public/js')
    .js('resources/js/filterdropdown.js', 'public/js')
    .js('resources/js/tablemenubtn.js', 'public/js')
    .js('resources/js/tablesort.js', 'public/js')
    .js('resources/js/jscodes.js', 'public/js')
    .js('resources/js/openmodal.js', 'public/js')
    .js('resources/js/openmodal2.js', 'public/js')
    .js('resources/js/openmodal3.js', 'public/js')
    .js('resources/js/openmodal4.js', 'public/js')
    .js('resources/js/openmodal5.js', 'public/js')
    .js('resources/js/openmodal6.js', 'public/js')
    .js('resources/js/openmodal7.js', 'public/js')
    .js('resources/js/openmodal8.js', 'public/js')
    .js('resources/js/openmodal9.js', 'public/js')
    .js('resources/js/openmodal10.js', 'public/js')
    .js('resources/js/bootstrap.js', 'public/js')
    .js('resources/js/langchange.js', 'public/js')
.postCss('resources/css/app.css', 'public/css')


