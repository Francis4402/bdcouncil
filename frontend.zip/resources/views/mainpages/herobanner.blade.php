<div class="swiperbody">
    <swiper-container style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="mySwiper h-[40rem]" pagination="true" pagination-clickable="true" navigation="true" space-between="30"
    centered-slides="true" autoplay-delay="2500" autoplay-disable-on-interaction="false">
    <swiper-slide>
        <img src="{{ asset('assets/backgroundimage/ref3.jpg') }}" alt="i">
    </swiper-slide>
    <swiper-slide>
        <img src="{{ asset('assets/backgroundimage/ref2.jpg') }}" alt="i">
    </swiper-slide>
    <swiper-slide>
        <img src="{{ asset('assets/backgroundimage/ref3.jpg') }}" alt="i">
    </swiper-slide>
    <swiper-slide>
        <img src="{{ asset('assets/backgroundimage/ref4.jpg') }}" alt="i">
    </swiper-slide>
    <swiper-slide>
        <img src="{{ asset('assets/backgroundimage/ref2.jpg') }}" alt="i">
    </swiper-slide>
  </swiper-container>
</div>